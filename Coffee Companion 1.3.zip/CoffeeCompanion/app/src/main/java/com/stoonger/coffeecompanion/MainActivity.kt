package com.stoonger.coffeecompanion

import android.app.Activity
import com.stoonger.coffeecompanion.ui.theme.CoffeeCompanionTheme
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.content.edit
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.mutableStateListOf
import kotlin.reflect.KProperty
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.DialogProperties
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

const val APP_VERSION = "1.3"
const val APP_BUILD = "Stable" // Type "Stable" or "Debug"

/**
 * MainActivity serves as the root entry point for the Coffee Companion application,
 * setting up the primary Jetpack Compose surface view upon activity creation.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val prefs = getSharedPreferences("coffee_prefs", MODE_PRIVATE)
        val isDarkThemePref = prefs.getBoolean("dark_mode", false)


        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var isDarkTheme by remember {
                mutableStateOf(isDarkThemePref)
            }

            CoffeeCompanionTheme(darkTheme = isDarkTheme) {
                Surface(
                    modifier = Modifier
                        .fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Box(modifier = Modifier.statusBarsPadding()) {
                        CoffeeInventoryScreen(
                            isDarkTheme = isDarkTheme,
                            onThemeChanged = { newValue ->
                                isDarkTheme = newValue
                                prefs.edit { putBoolean("dark_mode", newValue) }
                            }
                        )
                    }
                }
            }
        }
    }

    /**
     * Data class representing a configured grinder and its brew method parameters,
     * including default grind size and optional dose in / weight out specifications.
     */
    data class GrinderSetting(
        val grinderName: String,
        val brewMethod: String,
        val defaultGrindSize: String,
        val defaultTemp: String = "93°C",
        val defaultDoseIn: String = "",
        val defaultWeightOut: String = "",
        val recipeInfo: String = ""
    )

    /**
     * Data class defining the baseline ratio configuration
     * utilized by the interactive brew calculator widget.
     */
    data class DefaultRatioSetting(
        val defaultDose: String,
        val defaultWater: String
    )

    /** Data class representing a single logged attempt during an active dial-in session. */
    data class DialInLogEntry(
        val id: Int,
        val grindSize: String,
        val temp: String = "93°C",
        val doseIn: String,
        val weightOut: String,
        val timeMinutes: String = "",
        val timeSeconds: String = "",
        val tasteNotes: String,
        val changeNextTime: String
    )

    /** Data class tracking an active dial-in workflow for a specific grinder and brew method pair. */
    data class DialInSession(
        val id: Int,
        val grinderName: String,
        val brewMethod: String,
        val logs: List<DialInLogEntry>
    )

    /** Data class representing a successfully completed dial-in summary record. */
    data class SuccessfulDialInRecord(
        val grinderName: String,
        val brewMethod: String,
        val summaryText: String
    )

    /**
     * Data class representing an active bag of coffee beans, containing inventory weights,
     * roaster attribution, active dial-in records, re-order flags, and dose preset lists.
     */
    data class CoffeeBag(
        val id: Int,
        val name: String,
        val roasterName: String,
        val tastingNotes: String = "",
        val roasterUrl: String,
        val remainingGrams: Int,
        val totalGrams: Int,
        val roastDate: LocalDate,
        val availableGrinders: List<GrinderSetting>,
        val defaultRatio: DefaultRatioSetting,
        val activeDialInSessions: List<DialInSession>,
        val isBagOrdered: Boolean = false,
        val dosePresets: List<Int> = listOf(18, 30),
        val successfulDialIns: List<SuccessfulDialInRecord> = emptyList()
    )

    /** Supplies fallback placeholder values when initializing a fresh coffee bag instance. */
    fun defaultCoffeeBag(): CoffeeBag {
        return CoffeeBag(
            id = 1,
            name = "Bag Name",
            roasterName = "Roaster Name",
            tastingNotes = "",
            roasterUrl = "",
            remainingGrams = 0,
            totalGrams = 0,
            roastDate = LocalDate.now(),
            availableGrinders = emptyList(),
            defaultRatio = DefaultRatioSetting("15", "250"),
            activeDialInSessions = emptyList(),
            isBagOrdered = false,
            dosePresets = listOf(18, 30),
            successfulDialIns = emptyList()
        )
    }

    /** Loads stored CoffeeBag data from Android SharedPreferences using safe JSON parsing. */
    fun loadCoffeeBag(context: Context): CoffeeBag {
        val prefs = context.getSharedPreferences("coffee_prefs", MODE_PRIVATE)
        val jsonStr = prefs.getString("coffee_bag_data", null) ?: return defaultCoffeeBag()
        try {
            val obj = JSONObject(jsonStr)
            val id = obj.getInt("id")
            val name = obj.getString("name")
            val roasterName = obj.getString("roasterName")
            val tastingNotes = obj.optString("tastingNotes", "")
            val roasterUrl = obj.getString("roasterUrl")
            val remainingGrams = obj.getInt("remainingGrams")
            val totalGrams = obj.getInt("totalGrams")
            val roastDateStr = obj.getString("roastDate")
            val roastDate = try {
                LocalDate.parse(roastDateStr)
            } catch (_: Exception) {
                LocalDate.now()
            }
            val isBagOrdered = obj.optBoolean("isBagOrdered", false)

            val grindersArray = obj.getJSONArray("availableGrinders")
            val grinders = mutableListOf<GrinderSetting>()
            for (i in 0 until grindersArray.length()) {
                val gObj = grindersArray.getJSONObject(i)
                grinders.add(
                    GrinderSetting(
                        grinderName = gObj.getString("grinderName"),
                        brewMethod = gObj.getString("brewMethod"),
                        defaultGrindSize = gObj.getString("defaultGrindSize"),
                        defaultTemp = gObj.optString("defaultTemp", "93°C"),
                        defaultDoseIn = gObj.optString("defaultDoseIn", ""),
                        defaultWeightOut = gObj.optString("defaultWeightOut", ""),
                        recipeInfo = gObj.optString("recipeInfo", "")
                    )
                )
            }

            val ratioObj = obj.getJSONObject("defaultRatio")
            val defaultRatio = DefaultRatioSetting(
                ratioObj.getString("defaultDose"),
                ratioObj.getString("defaultWater")
            )

            val sessionsArray = obj.getJSONArray("activeDialInSessions")
            val sessions = mutableListOf<DialInSession>()
            for (i in 0 until sessionsArray.length()) {
                val sObj = sessionsArray.getJSONObject(i)
                val logsArray = sObj.getJSONArray("logs")
                val logs = mutableListOf<DialInLogEntry>()
                for (j in 0 until logsArray.length()) {
                    val lObj = logsArray.getJSONObject(j)
                    logs.add(
                        DialInLogEntry(
                            lObj.getInt("id"),
                            lObj.getString("grindSize"),
                            temp = lObj.optString("temp", "93°C"),
                            lObj.getString("doseIn"),
                            lObj.getString("weightOut"),
                            lObj.optString("timeMinutes", ""),
                            lObj.optString("timeSeconds", ""),
                            lObj.getString("tasteNotes"),
                            lObj.getString("changeNextTime")
                        )
                    )
                }
                sessions.add(
                    DialInSession(
                        sObj.getInt("id"),
                        sObj.getString("grinderName"),
                        sObj.getString("brewMethod"),
                        logs
                    )
                )
            }

            val presetsArray = obj.optJSONArray("dosePresets")
            val dosePresets = mutableListOf<Int>()
            if (presetsArray != null) {
                for (i in 0 until presetsArray.length()) {
                    dosePresets.add(presetsArray.getInt(i))
                }
            } else {
                dosePresets.addAll(listOf(18, 30, 36))
            }

            val successfulArray = obj.optJSONArray("successfulDialIns")
            val successfulDialIns = mutableListOf<SuccessfulDialInRecord>()
            if (successfulArray != null) {
                for (i in 0 until successfulArray.length()) {
                    val sObj = successfulArray.getJSONObject(i)
                    successfulDialIns.add(
                        SuccessfulDialInRecord(
                            sObj.getString("grinderName"),
                            sObj.getString("brewMethod"),
                            sObj.getString("summaryText")
                        )
                    )
                }
            }

            return CoffeeBag(
                id,
                name,
                roasterName,
                tastingNotes,
                roasterUrl,
                remainingGrams,
                totalGrams,
                roastDate,
                grinders,
                defaultRatio,
                sessions,
                isBagOrdered,
                dosePresets,
                successfulDialIns
            )
        } catch (_: Exception) {
            return defaultCoffeeBag()
        }
    }

    /** Persists the current CoffeeBag state into Android SharedPreferences using KTX edit extension. */
    fun saveCoffeeBag(context: Context, bag: CoffeeBag) {
        val prefs = context.getSharedPreferences("coffee_prefs", MODE_PRIVATE)
        val obj = JSONObject().apply {
            put("id", bag.id)
            put("name", bag.name)
            put("roasterName", bag.roasterName)
            put("tastingNotes", bag.tastingNotes)
            put("roasterUrl", bag.roasterUrl)
            put("remainingGrams", bag.remainingGrams)
            put("totalGrams", bag.totalGrams)
            put("roastDate", bag.roastDate.toString())
            put("isBagOrdered", bag.isBagOrdered)

            val grindersArray = JSONArray()
            bag.availableGrinders.forEach { g ->
                grindersArray.put(JSONObject().apply {
                    put("grinderName", g.grinderName)
                    put("brewMethod", g.brewMethod)
                    put("defaultGrindSize", g.defaultGrindSize)
                    put("defaultTemp", g.defaultTemp)
                    put("defaultDoseIn", g.defaultDoseIn)
                    put("defaultWeightOut", g.defaultWeightOut)
                    put("recipeInfo", g.recipeInfo)
                })
            }
            put("availableGrinders", grindersArray)

            put("defaultRatio", JSONObject().apply {
                put("defaultDose", bag.defaultRatio.defaultDose)
                put("defaultWater", bag.defaultRatio.defaultWater)
            })

            val sessionsArray = JSONArray()
            bag.activeDialInSessions.forEach { s ->
                sessionsArray.put(JSONObject().apply {
                    put("id", s.id)
                    put("grinderName", s.grinderName)
                    put("brewMethod", s.brewMethod)
                    val logsArray = JSONArray()
                    s.logs.forEach { l ->
                        logsArray.put(JSONObject().apply {
                            put("id", l.id)
                            put("grindSize", l.grindSize)
                            put("temp", l.temp)
                            put("doseIn", l.doseIn)
                            put("weightOut", l.weightOut)
                            put("timeMinutes", l.timeMinutes)
                            put("timeSeconds", l.timeSeconds)
                            put("tasteNotes", l.tasteNotes)
                            put("changeNextTime", l.changeNextTime)
                        })
                    }
                    put("logs", logsArray)
                })
            }
            put("activeDialInSessions", sessionsArray)

            val presetsArray = JSONArray()
            bag.dosePresets.forEach { presetsArray.put(it) }
            put("dosePresets", presetsArray)

            val successfulArray = JSONArray()
            bag.successfulDialIns.forEach { s ->
                successfulArray.put(JSONObject().apply {
                    put("grinderName", s.grinderName)
                    put("brewMethod", s.brewMethod)
                    put("summaryText", s.summaryText)
                })
            }
            put("successfulDialIns", successfulArray)
        }
        prefs.edit {
            putString("coffee_bag_data", obj.toString())
        }
    }

    class NavStackState(private val initial: String = "main") {
        val stack = mutableStateListOf(initial)

        operator fun getValue(thisRef: Any?, property: KProperty<*>): String {
            return stack.lastOrNull() ?: initial
        }

        operator fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            if (stack.lastOrNull() != value) {
                val index = stack.indexOf(value)
                if (index != -1) {
                    while (stack.size > index + 1) {
                        stack.removeAt(stack.lastIndex)
                    }
                } else {
                    stack.add(value)
                }
            }
        }

        fun pop(): Boolean {
            if (stack.size > 1) {
                stack.removeAt(stack.lastIndex)
                return true
            }
            return false
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun CoffeeInventoryScreen(
        isDarkTheme: Boolean,
        onThemeChanged: (Boolean) -> Unit
    ) {
        val context = LocalContext.current
        var activeBag by remember { mutableStateOf(loadCoffeeBag(context)) }

        // Automatically trigger saving state whenever active coffee bag data changes
        LaunchedEffect(activeBag) {
            saveCoffeeBag(context, activeBag)
        }

        val navState = remember { NavStackState("main") }
        var currentScreen by navState

        var selectedGrinderName by remember { mutableStateOf("") }
        var selectedBrewMethod by remember { mutableStateOf("") }
        var showEditDialog by remember { mutableStateOf(false) }
        var showRemainingDialog by remember { mutableStateOf(false) }
        var showTempRatioDialog by remember { mutableStateOf(false) }

        // Hierarchical back handling pops the stack accurately
        BackHandler {
            when {
                showTempRatioDialog -> showTempRatioDialog = false
                showRemainingDialog -> showRemainingDialog = false
                showEditDialog -> showEditDialog = false
                else -> {
                    if (!navState.pop()) {
                        (context as? Activity)?.finish()
                    }
                }
            }
        }

        // Transient temporary ratio override for the current session (clears on app close)
        var tempRatioOverride by remember { mutableStateOf<Double?>(null) }
        var tempRatioInput by remember { mutableStateOf("") }
        var isRatioUnlocked by remember { mutableStateOf(false) }

        // Input state variables for the remaining grams popup dialog options
        var addRemainingAmount by remember { mutableStateOf("") }
        var replaceRemainingAmount by remember { mutableStateOf("") }
        var subtractRemainingAmount by remember { mutableStateOf("") }

        val keyboardController = LocalSoftwareKeyboardController.current
        val focusManager = LocalFocusManager.current
        val haptic = LocalHapticFeedback.current

        val locale = LocalConfiguration.current.locales[0]
        val dateFormatter = remember(locale) { DateTimeFormatter.ofPattern("dd/MM/yyyy", locale) }

        var editName by remember(activeBag) { mutableStateOf(activeBag.name) }
        var editRoaster by remember(activeBag) { mutableStateOf(activeBag.roasterName) }
        var editTastingNotes by remember(activeBag) { mutableStateOf(activeBag.tastingNotes) }
        var editTotal by remember(activeBag) { mutableStateOf(activeBag.totalGrams.toString()) }
        var editRoastDate by remember(activeBag) {
            mutableStateOf(
                activeBag.roastDate.format(
                    dateFormatter
                )
            )
        }

        // Reset toggle unchecked by default when opening edit area
        var resetNextBag by remember { mutableStateOf(false) }

        val nameOrRoasterChanged =
            editName != activeBag.name || editRoaster != activeBag.roasterName

        // Automatically tick reset checkbox when name or roaster modifications occur
        LaunchedEffect(nameOrRoasterChanged) {
            if (nameOrRoasterChanged) {
                resetNextBag = true
            }
        }

        var calcDose by remember(activeBag.defaultRatio) { mutableStateOf(activeBag.defaultRatio.defaultDose) }
        var calcWater by remember(activeBag.defaultRatio) { mutableStateOf(activeBag.defaultRatio.defaultWater) }

        val defaultDoseNum = activeBag.defaultRatio.defaultDose.toDoubleOrNull() ?: 15.0
        val defaultWaterNum = activeBag.defaultRatio.defaultWater.toDoubleOrNull() ?: 250.0
        val fixedRatio = if (defaultDoseNum > 0) defaultWaterNum / defaultDoseNum else 16.666

        val activeRatio = tempRatioOverride ?: fixedRatio

        val doseValue = calcDose.toDoubleOrNull() ?: 0.0
        val waterValue = calcWater.toDoubleOrNull() ?: 0.0
        val computedRatio = if (doseValue > 0) waterValue / doseValue else 0.0

        val isCustomRatio =
            (calcDose.toDoubleOrNull() ?: 0.0) != (activeBag.defaultRatio.defaultDose.toDoubleOrNull() ?: 0.0) ||
                    (calcWater.toDoubleOrNull() ?: 0.0) != (activeBag.defaultRatio.defaultWater.toDoubleOrNull() ?: 0.0) ||
                    tempRatioOverride != null || isRatioUnlocked

        val bloomWeight = doseValue * 3.0
        val remainingWater = (waterValue - bloomWeight).coerceAtLeast(0.0)
        val splitPourWeight = remainingWater / 2.0

        val daysAgo = ChronoUnit.DAYS.between(activeBag.roastDate, LocalDate.now())
        val formattedRoastDate = activeBag.roastDate.format(dateFormatter)

        val freshnessColor = when {
            daysAgo <= 14 -> Color(0xFF4CAF50)
            daysAgo <= 30 -> Color(0xFFFFEB3B)
            else -> Color(0xFFF44336)
        }

        // Navigation router switching between dashboard, sessions, and settings views
        when (currentScreen) {
            "dialInManagement" -> {
                DialInManagementView(
                    bag = activeBag,
                    onBack = { navState.pop() },
                    onSelectGrinderMethod = { grinder, method ->
                        selectedGrinderName = grinder
                        selectedBrewMethod = method
                        currentScreen = "sessionDetail"
                    },
                    onClearSession = { grinder, method ->
                        val session =
                            activeBag.activeDialInSessions.find { it.grinderName == grinder && it.brewMethod == method }
                        val latestLog = session?.logs?.lastOrNull()
                        val summary = if (latestLog != null) {
                            val timeDisplay = buildString {
                                val mins = latestLog.timeMinutes.trim()
                                val secs = latestLog.timeSeconds.trim()
                                if (mins.isNotBlank() && mins != "0") append("${mins}m ")
                                if (secs.isNotBlank()) append("${secs}s")
                            }.trim()
                            val timePart = if (timeDisplay.isNotBlank()) " - $timeDisplay" else ""
                            "$method - Grind ${latestLog.grindSize} - ${latestLog.temp} - ${latestLog.doseIn} - ${latestLog.weightOut}$timePart"
                        } else {
                            "$method - Dialed in"
                        }

                        val updatedSuccessful =
                            activeBag.successfulDialIns.filter { !(it.grinderName == grinder && it.brewMethod == method) } +
                                    SuccessfulDialInRecord(grinder, method, summary)

                        val updatedSessions = activeBag.activeDialInSessions.filter {
                            !(it.grinderName == grinder && it.brewMethod == method)
                        }
                        activeBag = activeBag.copy(
                            activeDialInSessions = updatedSessions,
                            successfulDialIns = updatedSuccessful
                        )
                    }
                )
                return
            }

            "sessionDetail" -> {
                val session = activeBag.activeDialInSessions.find {
                    it.grinderName == selectedGrinderName && it.brewMethod == selectedBrewMethod
                } ?: DialInSession(
                    id = (activeBag.activeDialInSessions.maxOfOrNull { it.id } ?: 0) + 1,
                    grinderName = selectedGrinderName,
                    brewMethod = selectedBrewMethod,
                    logs = emptyList()
                )

                val matchingGrinder = activeBag.availableGrinders.find {
                    it.grinderName == selectedGrinderName && it.brewMethod == selectedBrewMethod
                }

                DialInSessionDetailView(
                    session = session,
                    defaultTemp = matchingGrinder?.defaultTemp ?: "93°C",
                    defaultDoseIn = matchingGrinder?.defaultDoseIn ?: "",
                    defaultWeightOut = matchingGrinder?.defaultWeightOut ?: "",
                    onBack = { navState.pop() },
                    onAddLog = { newLog ->
                        val updatedLogs = session.logs + newLog
                        val updatedSession = session.copy(logs = updatedLogs)
                        val existingIndex = activeBag.activeDialInSessions.indexOfFirst {
                            it.grinderName == selectedGrinderName && it.brewMethod == selectedBrewMethod
                        }
                        val updatedSessions = if (existingIndex >= 0) {
                            activeBag.activeDialInSessions.mapIndexed { index, s -> if (index == existingIndex) updatedSession else s }
                        } else {
                            activeBag.activeDialInSessions + updatedSession
                        }
                        val updatedSuccessful = activeBag.successfulDialIns.filter {
                            !(it.grinderName == selectedGrinderName && it.brewMethod == selectedBrewMethod)
                        }
                        activeBag = activeBag.copy(
                            activeDialInSessions = updatedSessions,
                            successfulDialIns = updatedSuccessful
                        )
                    },
                    onUpdateLog = { updatedLog ->
                        val updatedLogs =
                            session.logs.map { if (it.id == updatedLog.id) updatedLog else it }
                        val updatedSession = session.copy(logs = updatedLogs)
                        val existingIndex = activeBag.activeDialInSessions.indexOfFirst {
                            it.grinderName == selectedGrinderName && it.brewMethod == selectedBrewMethod
                        }
                        val updatedSessions = if (existingIndex >= 0) {
                            activeBag.activeDialInSessions.mapIndexed { index, s -> if (index == existingIndex) updatedSession else s }
                        } else {
                            activeBag.activeDialInSessions
                        }
                        activeBag = activeBag.copy(activeDialInSessions = updatedSessions)
                    },
                    onDeleteLog = { logId ->
                        val updatedLogs = session.logs.filter { it.id != logId }
                        val updatedSessions = if (updatedLogs.isEmpty()) {
                            activeBag.activeDialInSessions.filter {
                                !(it.grinderName == selectedGrinderName && it.brewMethod == selectedBrewMethod)
                            }
                        } else {
                            val updatedSession = session.copy(logs = updatedLogs)
                            activeBag.activeDialInSessions.map {
                                if (it.grinderName == selectedGrinderName && it.brewMethod == selectedBrewMethod) updatedSession else it
                            }
                        }
                        activeBag = activeBag.copy(activeDialInSessions = updatedSessions)
                    },
                    onClearLogs = {
                        val latestLog = session.logs.lastOrNull()
                        val summary = if (latestLog != null) {
                            val timeDisplay = buildString {
                                val mins = latestLog.timeMinutes.trim()
                                val secs = latestLog.timeSeconds.trim()
                                if (mins.isNotBlank() && mins != "0") append("${mins}m ")
                                if (secs.isNotBlank()) append("${secs}s")
                            }.trim()
                            val timePart = if (timeDisplay.isNotBlank()) " - $timeDisplay" else ""
                            "${session.brewMethod} - Grind ${latestLog.grindSize} - ${latestLog.temp} - ${latestLog.doseIn} - ${latestLog.weightOut}$timePart"
                        } else {
                            "${session.brewMethod} - Dialed in"
                        }

                        val updatedSuccessful =
                            activeBag.successfulDialIns.filter { !(it.grinderName == session.grinderName && it.brewMethod == session.brewMethod) } +
                                    SuccessfulDialInRecord(
                                        session.grinderName,
                                        session.brewMethod,
                                        summary
                                    )

                        val updatedSessions = activeBag.activeDialInSessions.filter {
                            !(it.grinderName == selectedGrinderName && it.brewMethod == selectedBrewMethod)
                        }
                        activeBag = activeBag.copy(
                            activeDialInSessions = updatedSessions,
                            successfulDialIns = updatedSuccessful
                        )
                    }
                )
                return
            }

            "settings" -> {
                SettingsView(
                    onBack = { navState.pop() },
                    onNavigateAppSettings = { currentScreen = "appSettings" },
                    onNavigateBrewSettings = { currentScreen = "brewSettings" },
                    onResetAll = {
                        context.getSharedPreferences("coffee_prefs", MODE_PRIVATE)
                            .edit { clear() }
                        activeBag = defaultCoffeeBag()
                        tempRatioOverride = null
                        currentScreen = "main"
                    }
                )
                return
            }

            "appSettings" -> {
                AppSettingsView(
                    darkThemeEnabled = isDarkTheme,
                    onThemeToggle = onThemeChanged,
                    onBack = { navState.pop() }
                )
                return
            }

            "brewSettings" -> {
                BrewSettingsView(
                    grinderSettings = activeBag.availableGrinders,
                    defaultRatio = activeBag.defaultRatio,
                    dosePresets = activeBag.dosePresets,
                    onBack = { navState.pop() },
                    onUpdateGrinders = { updatedGrinders ->
                        activeBag = activeBag.copy(availableGrinders = updatedGrinders)
                    },
                    onUpdateDefaultRatio = { updatedRatio ->
                        activeBag = activeBag.copy(defaultRatio = updatedRatio)
                    },
                    onUpdateDosePresets = { updatedPresets ->
                        activeBag = activeBag.copy(dosePresets = updatedPresets)
                    }
                )
                return
            }
        }

        // Main dashboard layout wrapped in a vertical scroll container ensuring smooth scrolling behavior
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 16.dp,
                    end = 16.dp,
                    top = 12.dp,
                    bottom = 16.dp
                ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = activeBag.name, style = MaterialTheme.typography.headlineMedium)
                    Text(
                        text = activeBag.roasterName,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.secondary
                    )
                    if (activeBag.tastingNotes.isNotBlank()) {
                        Text(
                            text = activeBag.tastingNotes,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
                Row {
                    IconButton(onClick = { currentScreen = "settings" }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                    IconButton(onClick = { showEditDialog = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Coffee Bag")
                    }
                }
            }

            // Remaining weight card featuring top-right status checkbox and full card click listener for inventory updates
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showRemainingDialog = true }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(end = 95.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "Remaining: ${activeBag.remainingGrams}g / ${activeBag.totalGrams}g")
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier.size(12.dp)
                                    .background(freshnessColor, shape = CircleShape)
                            )
                            Text(text = "Roasted $daysAgo days ago ($formattedRoastDate)")
                        }
                    }
                    Row(
                        modifier = Modifier.align(Alignment.TopEnd),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "Next Bag?",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp
                        )
                        Checkbox(
                            checked = activeBag.isBagOrdered,
                            onCheckedChange = { checked ->
                                activeBag = activeBag.copy(isBagOrdered = checked)
                            },
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            Text(text = "Dose Presets", style = MaterialTheme.typography.titleMedium)
            activeBag.dosePresets.chunked(3).forEach { rowPresets ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    rowPresets.forEach { dose ->
                        Button(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                val newWeight = (activeBag.remainingGrams - dose).coerceAtLeast(0)
                                activeBag = activeBag.copy(remainingGrams = newWeight)
                            },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            Text("-${dose}g")
                        }
                    }
                    repeat(3 - rowPresets.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            Text(text = "Brew Calculator", style = MaterialTheme.typography.titleMedium)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = calcDose,
                            onValueChange = { newDose ->
                                calcDose = newDose
                                if (!isRatioUnlocked) {
                                    val doseNum = newDose.toDoubleOrNull()
                                    if (doseNum != null) {
                                        val calculatedWater = doseNum * activeRatio
                                        // Keep decimal if calculated value has a fractional part, otherwise drop it
                                        calcWater = if (calculatedWater % 1.0 == 0.0) {
                                            String.format(Locale.getDefault(), "%.0f", calculatedWater)
                                        } else {
                                            String.format(Locale.getDefault(), "%.1f", calculatedWater)
                                        }
                                    }
                                }
                            },
                            label = { Text("Dose (g)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = calcWater,
                            onValueChange = { newWater ->
                                calcWater = newWater
                                if (!isRatioUnlocked) {
                                    val waterNum = newWater.toDoubleOrNull()
                                    if (waterNum != null && activeRatio > 0) {
                                        val calculatedDose = waterNum / activeRatio
                                        // Keep decimal if calculated value has a fractional part, otherwise drop it
                                        calcDose = if (calculatedDose % 1.0 == 0.0) {
                                            String.format(Locale.getDefault(), "%.0f", calculatedDose)
                                        } else {
                                            String.format(Locale.getDefault(), "%.1f", calculatedDose)
                                        }
                                    }
                                }
                            },
                            label = { Text("Water (g)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                tempRatioInput =
                                    String.format(locale, "%.1f", activeRatio)
                                showTempRatioDialog = true
                            }
                    ) {
                        Text(
                            text = "${if (isRatioUnlocked) "Unlocked " else if (tempRatioOverride != null) "Temp " else ""}Brew Ratio: 1:${
                                String.format(locale, "%.1f", computedRatio)
                            }",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    if (isCustomRatio) {
                        HorizontalDivider()
                        Text(
                            text = "Bloom weight = ${
                                String.format(locale, "%.0f", bloomWeight)
                            }g. Pour ${
                                String.format(locale, "%.0f", splitPourWeight)
                            }ml at 1:00 (total ${
                                String.format(locale, "%.0f", bloomWeight + splitPourWeight)
                            }ml). Pour ${
                                String.format(locale, "%.0f", splitPourWeight)
                            }ml at 1:45 (total ${
                                String.format(locale, "%.0f", waterValue)
                            }ml).",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Successful dial-in summary box displayed right below the brew calculator card (without grinder name)
            if (activeBag.successfulDialIns.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    activeBag.successfulDialIns.sortedBy { it.brewMethod.lowercase(locale) }.forEach { record ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Text(
                                text = record.summaryText,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Active Dialing-In", style = MaterialTheme.typography.titleMedium)
                Button(onClick = { currentScreen = "dialInManagement" }) {
                    Text("Manage Dial-Ins")
                }
            }

            if (activeBag.activeDialInSessions.isEmpty()) {
                Text(
                    text = "No active dial-ins. Tap 'Manage Dial-Ins' to start one.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    activeBag.activeDialInSessions.sortedBy { it.brewMethod.lowercase(locale) }.forEach { session ->
                        val latestLog = session.logs.lastOrNull()
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedGrinderName = session.grinderName
                                    selectedBrewMethod = session.brewMethod
                                    currentScreen = "sessionDetail"
                                }
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${session.brewMethod} (${session.grinderName})",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = "${session.logs.size} attempts",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                if (latestLog != null) {
                                    val timeDisplay = buildString {
                                        val mins = latestLog.timeMinutes.trim()
                                        val secs = latestLog.timeSeconds.trim()
                                        if (mins.isNotBlank() && mins != "0") append("${mins}m ")
                                        if (secs.isNotBlank()) append("${secs}s")
                                    }.trim()
                                    val timePart =
                                        if (timeDisplay.isNotBlank()) " | $timeDisplay" else ""
                                    Text(text = "Grind: ${latestLog.grindSize} | Temp: ${latestLog.temp} | Yield: ${latestLog.weightOut}$timePart")
                                    Text(
                                        text = "Taste: ${latestLog.tasteNotes}",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Text(
                                        text = "Next time: ${latestLog.changeNextTime}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Temporary Ratio Dialog popup allowing users to enter a temporary ratio override
        if (showTempRatioDialog) {
            AlertDialog(
                onDismissRequest = { showTempRatioDialog = false },
                title = { Text("Temporary Brew Ratio") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Enter a temporary ratio value (e.g. 16.0 for 1:16). Affects both dose and water and resets on app close. You can also 'Unlock' the ratio to enter completely independent dose and water values.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        OutlinedTextField(
                            value = tempRatioInput,
                            onValueChange = { tempRatioInput = it },
                            label = { Text("Ratio Value (e.g., 16.0)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = {
                            showTempRatioDialog = false
                            keyboardController?.hide()
                            focusManager.clearFocus()
                        }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        TextButton(onClick = {
                            tempRatioOverride = null
                            isRatioUnlocked = false
                            calcDose = activeBag.defaultRatio.defaultDose
                            calcWater = activeBag.defaultRatio.defaultWater
                            showTempRatioDialog = false
                            keyboardController?.hide()
                            focusManager.clearFocus()
                        }) {
                            Text("Reset")
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        TextButton(onClick = {
                            isRatioUnlocked = true
                            tempRatioOverride = null
                            showTempRatioDialog = false
                            keyboardController?.hide()
                            focusManager.clearFocus()
                        }) {
                            Text("Unlock")
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        TextButton(onClick = {
                            val newRatioVal = tempRatioInput.toDoubleOrNull()
                            if (newRatioVal != null && newRatioVal > 0) {
                                tempRatioOverride = newRatioVal
                                isRatioUnlocked = false
                                val doseNum = calcDose.toDoubleOrNull()
                                if (doseNum != null) {
                                    calcWater = String.format(
                                        Locale.getDefault(),
                                        "%.1f",
                                        doseNum * newRatioVal
                                    )
                                }
                            }
                            showTempRatioDialog = false
                            keyboardController?.hide()
                            focusManager.clearFocus()
                        }) {
                            Text("Apply")
                        }
                    }
                }
            )
        }

        // Popup dialog for updating remaining inventory coffee weights with uniform input and button layout
        if (showRemainingDialog) {
            AlertDialog(
                onDismissRequest = { showRemainingDialog = false },
                title = { Text("Update Remaining Coffee") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = addRemainingAmount,
                                onValueChange = { addRemainingAmount = it },
                                label = { Text("Amount (g)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = {
                                    val addVal = addRemainingAmount.toIntOrNull() ?: 0
                                    val newRem =
                                        (activeBag.remainingGrams + addVal).coerceAtMost(activeBag.totalGrams)
                                    activeBag = activeBag.copy(remainingGrams = newRem)
                                    addRemainingAmount = ""
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                },
                                modifier = Modifier.width(110.dp)
                            ) {
                                Text("Add")
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = replaceRemainingAmount,
                                onValueChange = { replaceRemainingAmount = it },
                                label = { Text("Amount (g)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = {
                                    val repVal = replaceRemainingAmount.toIntOrNull()
                                        ?: activeBag.remainingGrams
                                    val newRem = repVal.coerceIn(0, activeBag.totalGrams)
                                    activeBag = activeBag.copy(remainingGrams = newRem)
                                    replaceRemainingAmount = ""
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                },
                                modifier = Modifier.width(110.dp)
                            ) {
                                Text("Replace")
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = subtractRemainingAmount,
                                onValueChange = { subtractRemainingAmount = it },
                                label = { Text("Amount (g)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = {
                                    val subVal = subtractRemainingAmount.toIntOrNull() ?: 0
                                    val newRem =
                                        (activeBag.remainingGrams - subVal).coerceAtLeast(0)
                                    activeBag = activeBag.copy(remainingGrams = newRem)
                                    subtractRemainingAmount = ""
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                },
                                modifier = Modifier.width(110.dp)
                            ) {
                                Text("Subtract")
                            }
                        }

                        if (activeBag.dosePresets.isNotEmpty()) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Text(text = "Available Doses Left:", style = MaterialTheme.typography.titleSmall)
                            activeBag.dosePresets.forEach { dose ->
                                val count = if (dose > 0) activeBag.remainingGrams / dose else 0
                                val spare = if (dose > 0) activeBag.remainingGrams % dose else 0
                                Text(
                                    text = "• You have $count more ${dose}g doses left (${spare}g spare)",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        showRemainingDialog = false
                        keyboardController?.hide()
                        focusManager.clearFocus()
                    }) {
                        Text("Close")
                    }
                }
            )
        }

        // Edit coffee bag properties dialog with automatic reset checkbox tracking
        if (showEditDialog) {
            AlertDialog(
                onDismissRequest = { showEditDialog = false },
                title = { Text("Edit Coffee Bag") },
                text = {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Bag Name") })
                        OutlinedTextField(
                            value = editTastingNotes,
                            onValueChange = { editTastingNotes = it },
                            label = { Text("Tasting Notes") })
                        OutlinedTextField(
                            value = editRoaster,
                            onValueChange = { editRoaster = it },
                            label = { Text("Roaster Name") })
                        OutlinedTextField(
                            value = editTotal,
                            onValueChange = { editTotal = it },
                            label = { Text("Total Grams") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )

                        if (nameOrRoasterChanged) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Checkbox(
                                    checked = resetNextBag,
                                    onCheckedChange = { resetNextBag = it }
                                )
                                Text(
                                    text = "New Bag?",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val initialDate = try {
                                        LocalDate.parse(editRoastDate, dateFormatter)
                                    } catch (_: Exception) {
                                        LocalDate.now()
                                    }
                                    android.app.DatePickerDialog(
                                        context,
                                        { _, year, month, dayOfMonth ->
                                            val newDate = LocalDate.of(year, month + 1, dayOfMonth)
                                            editRoastDate = newDate.format(dateFormatter)
                                        },
                                        initialDate.year,
                                        initialDate.monthValue - 1,
                                        initialDate.dayOfMonth
                                    ).show()
                                }
                        ) {
                            OutlinedTextField(
                                value = editRoastDate,
                                onValueChange = { },
                                label = { Text("Roasted On Date (DD/MM/YYYY)") },
                                readOnly = true,
                                enabled = false,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = MaterialTheme.colorScheme.onSurface,
                                    disabledBorderColor = MaterialTheme.colorScheme.outline,
                                    disabledLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val parsedRoastDate = try {
                            LocalDate.parse(editRoastDate, dateFormatter)
                        } catch (_: Exception) {
                            activeBag.roastDate
                        }
                        val newTotal = editTotal.toIntOrNull() ?: activeBag.totalGrams
                        val finalIsBagOrdered = if (resetNextBag) false else activeBag.isBagOrdered
                        val finalSessions = if (resetNextBag) emptyList() else activeBag.activeDialInSessions
                        val finalSuccessful = if (resetNextBag) emptyList() else activeBag.successfulDialIns

                        activeBag = activeBag.copy(
                            name = editName,
                            roasterName = editRoaster,
                            tastingNotes = editTastingNotes,
                            totalGrams = newTotal,
                            remainingGrams = newTotal,
                            roastDate = parsedRoastDate,
                            isBagOrdered = finalIsBagOrdered,
                            activeDialInSessions = finalSessions,
                            successfulDialIns = finalSuccessful
                        )
                        resetNextBag = false
                        showEditDialog = false
                        keyboardController?.hide()
                        focusManager.clearFocus()
                    }) {
                        Text("Save")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditDialog = false }) {
                        keyboardController?.hide()
                        focusManager.clearFocus()
                        Text("Cancel")
                    }
                }
            )
        }
    }

    /** Composable screen for managing active grinder and brew method dial-in sessions. */
    @Composable
    fun DialInManagementView(
        bag: CoffeeBag,
        onBack: () -> Unit,
        onSelectGrinderMethod: (String, String) -> Unit,
        onClearSession: (String, String) -> Unit
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(
                start = 16.dp,
                end = 16.dp,
                top = 8.dp,
                bottom = 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "Dialing-In Management",
                    style = MaterialTheme.typography.headlineMedium
                )
            }

            Text(text = "Grinders & Brew Methods", style = MaterialTheme.typography.titleMedium)

            val locale = LocalConfiguration.current.locales[0]
            val sortedGrinders = bag.availableGrinders.sortedBy { it.brewMethod.lowercase(locale) }

            if (sortedGrinders.isEmpty()) {
                Text(
                    text = "No grinders configured. Add one in settings first.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    sortedGrinders.forEach { setting ->
                        val session = bag.activeDialInSessions.find {
                            it.grinderName == setting.grinderName && it.brewMethod == setting.brewMethod
                        }
                        val hasLogs = session != null && session.logs.isNotEmpty()

                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            onSelectGrinderMethod(
                                                setting.grinderName,
                                                setting.brewMethod
                                            )
                                        }
                                ) {
                                    Text(
                                        text = "${setting.brewMethod} (${setting.grinderName})",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    if (hasLogs) {
                                        Text(
                                            text = "Attempts logged: ${session.logs.size}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    } else {
                                        Text(
                                            text = "Empty (Not dialed in yet)",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                }
                                if (hasLogs) {
                                    IconButton(onClick = {
                                        onClearSession(
                                            setting.grinderName,
                                            setting.brewMethod
                                        )
                                    }) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = "Mark as Dialed In / Clear",
                                            tint = Color(0xFF4CAF50)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /** Composable screen for viewing and adding dial-in attempts for a specific grinder/method session. */
    @Composable
    fun DialInSessionDetailView(
        session: DialInSession,
        defaultTemp: String,
        defaultDoseIn: String,
        defaultWeightOut: String,
        onBack: () -> Unit,
        onAddLog: (DialInLogEntry) -> Unit,
        onUpdateLog: (DialInLogEntry) -> Unit,
        onDeleteLog: (Int) -> Unit,
        onClearLogs: () -> Unit
    ) {
        var showAddDialog by remember { mutableStateOf(false) }
        var editingLog by remember { mutableStateOf<DialInLogEntry?>(null) }
        var grindSize by remember { mutableStateOf("") }
        var tempInput by remember { mutableStateOf(defaultTemp.replace("°C", "").ifBlank { "93" }) }
        var doseIn by remember { mutableStateOf(defaultDoseIn.ifBlank { "18g" }) }
        var weightOut by remember { mutableStateOf(defaultWeightOut.ifBlank { "36g" }) }
        var timeMinutes by remember { mutableStateOf("") }
        var timeSeconds by remember { mutableStateOf("") }
        var taste by remember { mutableStateOf("") }
        var change by remember { mutableStateOf("") }
        val keyboardController = LocalSoftwareKeyboardController.current
        val focusManager = LocalFocusManager.current

        Column(
            modifier = Modifier.fillMaxSize().padding(
                start = 16.dp,
                end = 16.dp,
                top = 8.dp,
                bottom = 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "${session.brewMethod} (${session.grinderName})",
                    style = MaterialTheme.typography.headlineMedium
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Attempt History", style = MaterialTheme.typography.titleMedium)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onClearLogs,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
                    ) {
                        Text("Dialled In", color = Color.White)
                    }
                    Button(onClick = {
                        editingLog = null
                        grindSize = ""
                        tempInput = defaultTemp.replace("°C", "").ifBlank { "93" }
                        doseIn = defaultDoseIn.ifBlank { "18g" }
                        weightOut = defaultWeightOut.ifBlank { "36g" }
                        timeMinutes = ""
                        timeSeconds = ""
                        taste = ""
                        change = ""
                        showAddDialog = true
                    }) {
                        Text("Add Attempt")
                    }
                }
            }

            if (session.logs.isEmpty()) {
                Text(
                    text = "No attempts logged yet for this grinder/method.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    session.logs.forEach { log ->
                        val timeDisplay = buildString {
                            val mins = log.timeMinutes.trim()
                            val secs = log.timeSeconds.trim()
                            if (mins.isNotBlank() && mins != "0") append("${mins}m ")
                            if (secs.isNotBlank()) append("${secs}s")
                        }.trim()
                        val timePart = if (timeDisplay.isNotBlank()) " | $timeDisplay" else ""

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    editingLog = log
                                    grindSize = log.grindSize
                                    tempInput = log.temp.replace("°C", "")
                                    doseIn = log.doseIn
                                    weightOut = log.weightOut
                                    timeMinutes = log.timeMinutes
                                    timeSeconds = log.timeSeconds
                                    taste = log.tasteNotes
                                    change = log.changeNextTime
                                    showAddDialog = true
                                }
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Grind: ${log.grindSize} | Temp: ${log.temp} | Yield: ${log.weightOut}$timePart",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    IconButton(onClick = { onDeleteLog(log.id) }) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                                Text(text = "Dose In: ${log.doseIn}")
                                Text(text = "Taste: ${log.tasteNotes}")
                                Text(
                                    text = "Next time: ${log.changeNextTime}",
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Dialog for logging a new dial-in attempt with split min/sec time inputs
        if (showAddDialog) {
            Dialog(
                onDismissRequest = { showAddDialog = false },
                properties = DialogProperties(
                    usePlatformDefaultWidth = false,
                    decorFitsSystemWindows = false
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .imePadding()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { showAddDialog = false },
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = MaterialTheme.shapes.extraLarge,
                        tonalElevation = 6.dp,
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .padding(24.dp)
                            .widthIn(max = 560.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { /* stop propagation */ }
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(24.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = if (editingLog == null) "Log New Dial-In Attempt" else "Edit Dial-In Attempt",
                                style = MaterialTheme.typography.headlineSmall
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                                    OutlinedTextField(
                                        value = grindSize,
                                        onValueChange = { grindSize = it },
                                        label = { Text("Grind Size") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = tempInput,
                                        onValueChange = { tempInput = it },
                                        label = { Text("Temperature") },
                                        suffix = { Text("°C") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                                    OutlinedTextField(
                                        value = doseIn.removeSuffix("g"),
                                        onValueChange = { doseIn = if (it.isNotBlank()) "${it}g" else "g" },
                                        label = { Text("Dose In") },
                                        suffix = { Text("g") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = weightOut.removeSuffix("g"),
                                        onValueChange = {
                                            weightOut = if (it.isNotBlank()) "${it}g" else "g"
                                        },
                                        label = { Text("Yield / Water In", maxLines = 1) },
                                        suffix = { Text("g") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                                    OutlinedTextField(
                                        value = timeMinutes,
                                        onValueChange = { timeMinutes = it },
                                        label = { Text("Minutes") },
                                        suffix = { Text("m") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = timeSeconds,
                                        onValueChange = { timeSeconds = it },
                                        label = { Text("Seconds") },
                                        suffix = { Text("s") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                OutlinedTextField(
                                    value = taste,
                                    onValueChange = { taste = it },
                                    label = { Text("Taste Notes") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = change,
                                    onValueChange = { change = it },
                                    label = { Text("Adjustment for Next Time") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = {
                                    showAddDialog = false
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                }) {
                                    Text("Cancel")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                TextButton(onClick = {
                                    val finalDoseIn = if (doseIn.endsWith("g")) doseIn else "${doseIn}g"
                                    val finalWeightOut =
                                        if (weightOut.endsWith("g")) weightOut else "${weightOut}g"

                                    val newEntry = DialInLogEntry(
                                        id = editingLog?.id ?: ((session.logs.maxOfOrNull { it.id } ?: 0) + 1),
                                        grindSize = grindSize,
                                        temp = if (tempInput.contains("°C")) tempInput else "${tempInput}°C",
                                        doseIn = finalDoseIn,
                                        weightOut = finalWeightOut,
                                        timeMinutes = timeMinutes.trim(),
                                        timeSeconds = timeSeconds.trim(),
                                        tasteNotes = taste,
                                        changeNextTime = change
                                    )
                                    if (editingLog == null) {
                                        onAddLog(newEntry)
                                    } else {
                                        onUpdateLog(newEntry)
                                    }
                                    showAddDialog = false
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                }) {
                                    Text("Save")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /** Composable screen representing App Settings root hub with a reset button at the bottom. */
    @Composable
    fun SettingsView(
        onBack: () -> Unit,
        onNavigateAppSettings: () -> Unit,
        onNavigateBrewSettings: () -> Unit,
        onResetAll: () -> Unit
    ) {
        var showResetConfirm by remember { mutableStateOf(false) }

        val keyboardController = LocalSoftwareKeyboardController.current
        val focusManager = LocalFocusManager.current



        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = 16.dp,
                    end = 16.dp,
                    top = 8.dp,
                    bottom = 16.dp
                ),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Text(text = "Settings", style = MaterialTheme.typography.headlineMedium)
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateAppSettings() }
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "App Settings", style = MaterialTheme.typography.titleMedium)
                            Text(text = "Dark mode and display options", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                        }
                    }
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateBrewSettings() }
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Brew Settings",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Default ratios, dose presets, and grinders",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }

            // Small reset button at the bottom of the settings page
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                OutlinedButton(
                    onClick = { showResetConfirm = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(text = "Reset All App Data", fontSize = 12.sp)
                }
                Text(
                    text = "Build $APP_VERSION ($APP_BUILD)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontSize = 10.sp
                )
            }
        }

        if (showResetConfirm) {
            AlertDialog(
                onDismissRequest = { showResetConfirm = false },
                title = { Text("Are you sure?") },
                text = { Text("All values in the app will be reset to their default values.") },
                confirmButton = {
                    TextButton(onClick = {
                        showResetConfirm = false
                        onResetAll()
                        keyboardController?.hide()
                        focusManager.clearFocus()
                    }) {
                        Text("Yes, Reset")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showResetConfirm = false
                        keyboardController?.hide()
                        focusManager.clearFocus()
                    }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }

    @Composable
    fun AppSettingsView(
        darkThemeEnabled: Boolean,
        onThemeToggle: (Boolean) -> Unit,
        onBack: () -> Unit
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(text = "App Settings", style = MaterialTheme.typography.headlineMedium)
            }

            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Dark Mode", style = MaterialTheme.typography.titleMedium)
                        Text(text = "Toggle light and dark theme", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary)
                    }
                    Switch(
                        checked = darkThemeEnabled,
                        onCheckedChange = onThemeToggle
                    )
                }
            }
        }
    }

    /** Composable screen for configuring default ratios, custom dose presets, and grinders. */
    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    fun BrewSettingsView(
        grinderSettings: List<GrinderSetting>,
        defaultRatio: DefaultRatioSetting,
        dosePresets: List<Int>,
        onBack: () -> Unit,
        onUpdateGrinders: (List<GrinderSetting>) -> Unit,
        onUpdateDefaultRatio: (DefaultRatioSetting) -> Unit,
        onUpdateDosePresets: (List<Int>) -> Unit

    ) {
        val locale = LocalConfiguration.current.locales[0]
        var grinders by remember { mutableStateOf(grinderSettings) }
        var currentDefDose by remember { mutableStateOf(defaultRatio.defaultDose) }
        var currentDefWater by remember { mutableStateOf(defaultRatio.defaultWater) }
        var presets by remember { mutableStateOf(dosePresets) }

        var showAddGrinderDialog by remember { mutableStateOf(false) }
        var editingGrinderIndex by remember { mutableStateOf<Int?>(null) }

        var newGrinderName by remember { mutableStateOf("") }
        var newBrewMethod by remember { mutableStateOf("") }
        var newGrindSize by remember { mutableStateOf("") }
        var newDefaultTemp by remember { mutableStateOf("") }
        var newDefaultDoseIn by remember { mutableStateOf("") }
        var newDefaultWeightOut by remember { mutableStateOf("") }
        var newRecipeInfo by remember { mutableStateOf("") }

        var newPresetInput by remember { mutableStateOf("") }

        val keyboardController = LocalSoftwareKeyboardController.current
        val focusManager = LocalFocusManager.current

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 16.dp,
                    end = 16.dp,
                    top = 8.dp,
                    bottom = 16.dp
                ),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(text = "Brew Settings", style = MaterialTheme.typography.headlineMedium)
            }

            Text(
                text = "Default Brew Calculator Ratio",
                style = MaterialTheme.typography.titleMedium
            )
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = currentDefDose,
                            onValueChange = { currentDefDose = it },
                            label = { Text("Default Dose (g)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = currentDefWater,
                            onValueChange = { currentDefWater = it },
                            label = { Text("Default Water (g)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Button(
                        onClick = {
                            onUpdateDefaultRatio(
                                DefaultRatioSetting(
                                    currentDefDose,
                                    currentDefWater
                                )
                            )
                            keyboardController?.hide()
                            focusManager.clearFocus()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Default Ratio")
                    }
                }
            }

            Text(text = "Custom Dose Presets", style = MaterialTheme.typography.titleMedium)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newPresetInput,
                            onValueChange = { newPresetInput = it },
                            label = { Text("Preset Grams (e.g., 20)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                val valInt = newPresetInput.toIntOrNull()
                                if (valInt != null && !presets.contains(valInt)) {
                                    val updatedPresets = (presets + valInt).sorted()
                                    presets = updatedPresets
                                    onUpdateDosePresets(updatedPresets)
                                    newPresetInput = ""
                                }
                                keyboardController?.hide()
                                focusManager.clearFocus()
                            }
                        ) {
                            Text("Add Preset")
                        }
                    }
                    // FlowRow displaying presets with (✕) removal button right next to the value inside the chip
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        presets.forEach { preset ->
                            AssistChip(
                                onClick = {
                                    val updatedPresets = presets.filter { it != preset }
                                    presets = updatedPresets
                                    onUpdateDosePresets(updatedPresets)
                                },
                                label = { Text("${preset}g ✕") }
                            )
                        }
                    }
                }
            }

            Text(text = "Manage Grinders & Methods", style = MaterialTheme.typography.titleMedium)

            val sortedGrinders = grinders.sortedBy { it.brewMethod.lowercase(locale) }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                sortedGrinders.forEach { setting ->
                    val originalIndex = grinders.indexOf(setting)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                editingGrinderIndex = originalIndex
                                newGrinderName = setting.grinderName
                                newBrewMethod = setting.brewMethod
                                newGrindSize = setting.defaultGrindSize
                                newDefaultTemp = setting.defaultTemp
                                newDefaultDoseIn = setting.defaultDoseIn
                                newDefaultWeightOut = setting.defaultWeightOut
                                newRecipeInfo = setting.recipeInfo
                                showAddGrinderDialog = true
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = setting.brewMethod,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "Grinder: ${setting.grinderName} | Default: ${setting.defaultGrindSize}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                if (setting.recipeInfo.isNotBlank()) {
                                    Text(
                                        text = setting.recipeInfo,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.secondary,
                                        maxLines = 2
                                    )
                                }
                                if (setting.defaultDoseIn.isNotBlank() || setting.defaultWeightOut.isNotBlank()) {
                                    Text(
                                        text = "Default In/Yield: ${setting.defaultDoseIn} -> ${setting.defaultWeightOut}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Button(
                onClick = {
                    editingGrinderIndex = null
                    newGrinderName = ""
                    newBrewMethod = ""
                    newGrindSize = ""
                    newDefaultTemp = ""
                    newDefaultDoseIn = ""
                    newDefaultWeightOut = ""
                    newRecipeInfo = ""
                    showAddGrinderDialog = true
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Add Grinder Setting")
            }
        }

        // Dialog for adding or editing grinder settings with delete button relocated to the bottom-left corner
        if (showAddGrinderDialog) {
            Dialog(
                onDismissRequest = { showAddGrinderDialog = false },
                properties = DialogProperties(
                    usePlatformDefaultWidth = false,
                    decorFitsSystemWindows = false
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .imePadding()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { showAddGrinderDialog = false },
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = MaterialTheme.shapes.extraLarge,
                        tonalElevation = 6.dp,
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .padding(24.dp)
                            .widthIn(max = 560.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { /* stop propagation */ }
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(24.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Dialog title reflecting whether adding or editing
                            Text(
                                text = if (editingGrinderIndex == null) "Add Grinder & Method" else "Edit Grinder & Method",
                                style = MaterialTheme.typography.headlineSmall
                            )

                            // Form inputs for grinder properties
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = newGrinderName,
                                    onValueChange = { newGrinderName = it },
                                    label = { Text("Grinder Name (e.g., Niche Zero)") })
                                OutlinedTextField(
                                    value = newBrewMethod,
                                    onValueChange = { newBrewMethod = it },
                                    label = { Text("Brew Method (e.g., Espresso)") })
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = newGrindSize,
                                        onValueChange = { newGrindSize = it },
                                        label = { Text("Default Grind (e.g., 14.5)") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = newDefaultTemp,
                                        onValueChange = { newDefaultTemp = it },
                                        label = { Text("Default Temp") },
                                        suffix = { Text("°C") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                    OutlinedTextField(
                                        value = newDefaultDoseIn,
                                        onValueChange = { newDefaultDoseIn = it },
                                        label = { Text("Default Dose In") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = newDefaultWeightOut,
                                        onValueChange = { newDefaultWeightOut = it },
                                        label = { Text("Default Yield / Water In", maxLines = 1) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                OutlinedTextField(
                                    value = newRecipeInfo,
                                    onValueChange = { newRecipeInfo = it },
                                    label = { Text("Recipe Info / Notes") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 2
                                )
                            }

                            // Action buttons row with delete on bottom left and save/cancel on bottom right
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (editingGrinderIndex != null) {
                                    Button(
                                        onClick = {
                                            val updated =
                                                grinders.filterIndexed { i, _ -> i != editingGrinderIndex }
                                            grinders = updated
                                            onUpdateGrinders(updated)
                                            showAddGrinderDialog = false
                                            keyboardController?.hide()
                                            focusManager.clearFocus()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                        modifier = Modifier.height(36.dp),
                                        contentPadding = PaddingValues(
                                            horizontal = 12.dp,
                                            vertical = 4.dp
                                        )
                                    ) {
                                        Text("Delete", fontSize = 12.sp, color = Color.White)
                                    }
                                } else {
                                    Spacer(modifier = Modifier.width(1.dp))
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = {
                                        showAddGrinderDialog = false
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                    }) {
                                        Text("Cancel")
                                    }
                                    TextButton(onClick = {
                                        if (newGrinderName.isNotBlank() && newBrewMethod.isNotBlank()) {
                                            val newSetting = GrinderSetting(
                                                grinderName = newGrinderName,
                                                brewMethod = newBrewMethod,
                                                defaultGrindSize = newGrindSize.ifBlank { "10" },
                                                defaultTemp = newDefaultTemp,
                                                defaultDoseIn = if (newDefaultDoseIn.isNotBlank() && !newDefaultDoseIn.endsWith(
                                                        "g"
                                                    )
                                                ) "${newDefaultDoseIn}g" else newDefaultDoseIn,
                                                defaultWeightOut = if (newDefaultWeightOut.isNotBlank() && !newDefaultWeightOut.endsWith(
                                                        "g"
                                                    )
                                                ) "${newDefaultWeightOut}g" else newDefaultWeightOut,
                                                recipeInfo = newRecipeInfo
                                            )
                                            val updated = if (editingGrinderIndex != null) {
                                                grinders.mapIndexed { i, s -> if (i == editingGrinderIndex) newSetting else s }
                                            } else {
                                                grinders + newSetting
                                            }
                                            grinders = updated
                                            onUpdateGrinders(updated)
                                            showAddGrinderDialog = false
                                        }
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                    }) {
                                        Text("Save")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Preview(showBackground = true)
    @Composable
    fun CoffeePreview() {
        var isDarkTheme by remember { mutableStateOf(false) }

        CoffeeCompanionTheme(darkTheme = isDarkTheme) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                CoffeeInventoryScreen(
                    isDarkTheme = isDarkTheme,
                    onThemeChanged = { isDarkTheme = it }
                )
            }
        }
    }
}