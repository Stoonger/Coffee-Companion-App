plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

fun getAppProperty(regex: String, default: String): String {
    val text = providers.fileContents(layout.projectDirectory.file("src/main/java/com/stoonger/coffeecompanion/MainActivity.kt")).asText.orNull ?: ""
    return regex.toRegex().find(text)?.groupValues?.get(1) ?: default
}
val appVersion = getAppProperty("const val APP_VERSION = \"([^\"]*)\"", "1.0")
val appBuild = getAppProperty("const val APP_BUILD = \"([^\"]*)\"", "Stable")

android {
    namespace = "com.stoonger.coffeecompanion"
    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "com.stoonger.coffeecompanion"
        minSdk = 35
        targetSdk = 37
        versionCode = 1
        versionName = appVersion

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        compose = true
    }

}

androidComponents {
    onVariants { variant ->
        variant.outputs.forEach { output ->
            val currentBuild = getAppProperty("const val APP_BUILD = \"([^\"]*)\"", "Stable")
            val suffix = if (currentBuild.equals("Debug", ignoreCase = true)) " Debug" else ""
            @Suppress("UnstableApiUsage")
            output.outputFileName.set("Coffee Companion $appVersion$suffix.apk")
        }
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.core.splashscreen)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.google.material)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)
    implementation(libs.androidx.compose.material.icons.extended)
}